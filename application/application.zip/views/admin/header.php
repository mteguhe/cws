<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Suang Gown</title>
<meta content="Suang Gown, Suang Gown Collections, Pusat gaun pengantin" name="keywords">
<meta content="Suang Gown Collections adalah Pusat Gaun Pengantin di Jakarta." name="description">
<link type="text/css" href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
<link href="pictures/32pbthm.ico" rel="shortcut icon">
<script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-35732491-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script><!--[if lte IE 6]>
<script type="text/javascript" src="supersleight-min.js"></script>
<![endif]-->
</head>



<!--[if IE]>
<div align=center>
<![endif]-->
<body><div id="container">
    <div id="header">
    <table width="960" border="0">
    <!--header part -->
    <tbody><tr valign="top"><td align="left"><a href="http://www.suanggown.com">
        <img border="0" align="left" src="<?php echo base_url();?>images/suang-gown.jpg"></a>
    </td><td align="right"><div id="search_div"><form enctype="multipart/form-data" method="post" action="search_bounce.php">

<div id="searchbox-wrapper">
<table width="320" cellspacing="0" cellpadding="0" border="0"><tbody><tr valign="top" height="26">
<td width="218" align="left">
<input type="text" maxlength="20" onFocus="this.value == 			this.defaultValue &amp;&amp; (this.value = '');" onBlur="this.value = this.value || this.defaultValue;" value="Search Product" name="search" id="searchbox-text"></td>
<td width="27" align="right">
<input type="image" onClick="submit_form();" alt="Search" src="<?php echo base_url();?>images/search_button.jpg" id="searchbox-btn">
</td></tr></tbody></table></div>

</form>
</div></td></tr>
    </tbody></table>
    </div>
