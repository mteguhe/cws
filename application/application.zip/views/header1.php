<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Central Wedding Store | Pusat Gaun dan perlengkapan pernikahan</title>
<link href="<?php echo base_url();?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url();?>js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="<?php echo base_url();?>css/style1.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() 
	{ setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }>
</script>

<meta name="keywords" content="Gaun Pengantin wanita - pria" />
<!--Google Fonts-->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url();?>js/move-top.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/easing.js"></script>


	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
</script>


<!-- //end-smoth-scrolling -->
<script src="<?php echo base_url(); ?>js/menu_jquery.js"></script>

<!---pop-up-box---->
					<link href="<?php echo base_url();?>css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
					<script src="<?php echo base_url();?>js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!---//pop-up-box---->
					 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
				</script>		
</head>
<body>
<!--header start here-->
<div class="header">
	<div class="container">
		<div class="header-main">
			   <div class="head-left">
				   	<div class="phone">
				   		<h1><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>images/Logo.png"></a></h1>
				   	</div>
				   	
	        <!---->
	              <div class="clearfix"> </div>
                </div>
			   <div class="header-right">
				   <div class="logo">
				   	   
				   </div>
				   <div class="header-login">
					 <div class="top-nav-right">
						<div class="search">		
			              <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i> </i></a>
		            </div>
				     <div id="small-dialog" class="mfp-hide">
					<div class="search-top">
							<div class="login">
								<input type="submit" value="">
								<input type="text" value="Search Here..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}">		
							</div>
							<p>Agrom</p>
						</div>				
					</div>
				   </div>
		      </div>
		    <div class="clearfix"> </div>
	     </div>
	     <div class="clearfix"> </div>
     </div>
   </div>
</div>
<!--header end here-->

<!--top nav start-->
<div class="top-navg-main">
	<div class="container">
	    <div class="top-navg">
	    	           <span class="menu"> <img src="<?php echo base_url(); ?>images/icon.png" alt=""/></span>
				<ul class="res">
				    <li><a href="<?php echo base_url();?>" class="active hvr-sweep-to-bottom">Home</a></li> 
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>awal/about">Profil</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>awal/collection">Produks</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>awal/how_to_buy">Order</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>awal/testimonial">Testimonial</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>promo">Promo Ekstra</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>contact">Contact Us</a></li>
					<li><a class="hvr-sweep-to-bottom" href="<?php echo base_url();?>trend">Trend Mode</a></li> 				 
				 
				 <hr>
				 <div class="row"></div>
					<!-- script-for-menu -->
						 <script>
						   $( "span.menu" ).click(function() {
							 $( "ul.res" ).slideToggle( 300, function() {
							 // Animation complete.
							  });
							 });
						</script>
		        <!-- /script-for-menu -->
		   </div>
	 </div>
</div>  
<!--top nav end here-->
