<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Suang Gown</title>
<meta content="Suang Gown, Suang Gown Collections, Pusat gaun pengantin" name="keywords">
<meta content="Suang Gown Collections adalah Pusat Gaun Pengantin di Jakarta." name="description">
<link type="text/css" href="configuration/style.css" rel="stylesheet">
<link href="pictures/32pbthm.ico" rel="shortcut icon">
<script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script><script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-35732491-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script><!--[if lte IE 6]>
<script type="text/javascript" src="supersleight-min.js"></script>
<![endif]-->
<style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow-x:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset&gt;div{overflow:hidden}.fb_link img{border:none}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;_background-image:url(http://static.ak.fbcdn.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif);cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent;_background-image:url(http://static.ak.fbcdn.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif)}.fb_dialog_close_icon:active{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent;_background-image:url(http://static.ak.fbcdn.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif)}.fb_dialog_loader{background-color:#f6f7f8;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #3a5795;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title&gt;span{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;left:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #2f477a;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f8;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(http://static.ak.fbcdn.net/rsrc.php/v2/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(http://static.ak.fbcdn.net/rsrc.php/v2/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}</style><script type="text/javascript" charset="utf-8" async="" src="https://platform.twitter.com/js/button.aec556e1a316f63b43fda3ae1e6a3e10.js"></script></head>



<!--[if IE]>
<div align=center>
<![endif]-->
<body><div id="container">
    <div id="header">
    <table width="960" border="0">
    <!--header part -->
    <tbody><tr valign="top"><td align="left"><a href="http://www.suanggown.com">
        <img border="0" align="left" src="images/suang-gown.jpg"></a>
    </td><td align="right"><div id="search_div"><form enctype="multipart/form-data" method="post" action="search_bounce.php">

<div id="searchbox-wrapper">
<table width="320" cellspacing="0" cellpadding="0" border="0"><tbody><tr valign="top" height="26">
<td width="218" align="left">
<input type="text" maxlength="20" onFocus="this.value == 			this.defaultValue &amp;&amp; (this.value = '');" onBlur="this.value = this.value || this.defaultValue;" value="Search Product" name="search" id="searchbox-text"></td>
<td width="27" align="right">
<input type="image" onClick="submit_form();" alt="Search" src="images/search_button.jpg" id="searchbox-btn">
</td></tr></tbody></table></div>

</form>
</div></td></tr>
    </tbody></table>
    </div>
    
	<div class="hr_menubar"></div>
	<div id="menu_container"><div class="menu"><a href="index.php">Home</a></div>
<div class="menu"><a href="?menu=about">About Us</a></div>
<div class="menu"><a href="?menu=product_cat">Collections</a></div>
<div class="menu"><a href="?menu=testimonial">Testimonial</a></div>
<div class="menu"><a href="?menu=how_to_buy">How To Order</a></div>
<div class="menu"><a href="?menu=article">Article</a></div>
<div class="menu"><a href="?menu=faq">Faq</a></div>
<div class="menu"><a href="?menu=contact">Contact Us</a></div>
</div>
	
    <div id="content_container"><link href="configuration/jquery.jqzoom.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="js/jquery-1.6.js"></script>
<script type="text/javascript" src="js/jquery.jqzoom-core.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$('.jqzoom').jqzoom({
            zoomType: 'standard',
            lens:true,
            preloadImages: false,
            alwaysOn:false,  
 	        zoomWidth: 350,  
    	    zoomHeight:350
        });
});
</script>
<div id="content">
<table width="960" class="content_table"><tbody><tr valign="top"><td width="220" height="450">
<div id="left">
<h1>COLLECTION</h1>
<br><br>
	<div class="left_menu">    
    <ul class="left_menu">
	<li><a href="?menu=product_cat&amp;id=24"><b>Wedding Gown Tail / Ekor</b></a></li><li><a href="?menu=product_cat&amp;id=2"><span class="space1">&nbsp;</span>WD Range 2 - 3 Jt</a></li><li><a href="?menu=product_cat&amp;id=19"><span class="space1">&nbsp;</span>High Quality 3 - 5 Jt</a></li><li><a href="?menu=product_cat&amp;id=57"><span class="space1">&nbsp;</span>Taiwan High Quality Up 5 Jt</a></li><li><a href="?menu=product_cat&amp;id=34"><span class="space1">&nbsp;</span>Mermaid / A Line</a></li><li><a href="?menu=product_cat&amp;id=26"><b>Wedding Gown No Tail</b></a></li><li><a href="?menu=product_cat&amp;id=23"><b>Gaun Depan Pendek Ekor</b></a></li><li><a href="?menu=product_cat&amp;id=77"><b>Wedding Gown Ekor Warna</b></a></li><li><a href="?menu=product_cat&amp;id=6"><b>Evening Gown / Pesta</b></a></li><li><a href="?menu=product_cat&amp;id=75"><b>Long Dress</b></a></li><li><a href="?menu=product_cat&amp;id=69"><b>Mini Dress</b></a></li><li><a href="?menu=product_cat&amp;id=31"><b>Gown Mama</b></a></li><li><a href="?menu=product_cat&amp;id=37"><b>Jas Pria (Promo)</b></a></li><li><a href="?menu=product_cat&amp;id=45"><b>SALE CUCI GUDANG Kebaya / Gaun Tradisional </b></a></li><li><a href="?menu=product_cat&amp;id=7"><b>Gaun Design / Custom Made</b></a></li><li><a href="?menu=product_cat&amp;id=32"><b>Bolero - Cardigan</b></a></li><li><a href="?menu=product_cat&amp;id=11"><b>Veil / Slayer</b></a></li><li><a href="?menu=product_cat&amp;id=54"><b>Sarung Tangan</b></a></li><li><a href="?menu=product_cat&amp;id=8"><b>Perlengkapan Pengantin</b></a></li><li><a href="?menu=product_cat&amp;id=68"><b>Crown+Necklace Set</b></a></li><li><a href="?menu=product_cat&amp;id=10"><b>Tiara / Crown</b></a></li><li><a href="?menu=product_cat&amp;id=50"><b>Kalung Set / Necklace </b></a></li><li><a href="?menu=product_cat&amp;id=73"><b>Hair Acc / Aksessories Rambut</b></a></li><li><a href="?menu=product_cat&amp;id=53"><b>Peralatan Make Up artist</b></a></li><li><a href="?menu=product_cat&amp;id=61"><b>Nail Art Wedding</b></a></li><li><a href="?menu=product_cat&amp;id=71"><b>Payung Prewed</b></a></li><li><a href="?menu=product_cat&amp;id=35"><b>Hand Bouget / Bunga Tangan</b></a></li><li><a href="?menu=product_cat&amp;id=88"><b>Make-Up Wed hari H</b></a></li><li><a href="?menu=product_cat&amp;id=51"><b>Stone Crystal</b></a></li><li><a href="?menu=product_cat&amp;id=74"><b>Kursus Private Make-Up Artist Prof</b></a></li><li><a href="?menu=product_cat&amp;id=82"><b>PROMO SALE CUCI GUDANG</b></a></li><li><a href="?menu=product_cat&amp;id=83"><b>Jam Trendy Swiss</b></a></li>    </ul>
    </div>
    </div>
</td><td>
<table width="720" border="0"><tbody><tr valign="top"><td width="310" align="center">        <div class="clearfix">
            <div class="clearfix">
                <a title="" rel="gal1" class="jqzoom" href="product/642208-468-(1).JPG" style="outline-style: none; text-decoration: none;">
                <div class="zoomPad"><img class="zoom_thumb" title="Gaun Wedding 208-468" src="product/thumb642208-468-(1).JPG" style="opacity: 1;"><div class="zoomPup" style="display: none; top: 65px; left: 0px; width: 116px; height: 116px; position: absolute; border-width: 1px;"></div><div class="zoomWindow" style="position: absolute; z-index: 5001; left: 312px; top: 0px; display: none;"><div class="zoomWrapper" style="width: 350px;"><div class="zoomWrapperTitle" style="width: 100%; position: absolute; display: block;">Gaun Wedding 208-468</div><div class="zoomWrapperImage" style="width: 100%; height: 350px;"><img style="position: absolute; border: 0px none; display: block; left: 0px; top: -195px;" src="product/642208-468-(1).JPG"></div></div></div><div class="zoomPreload" style="visibility: hidden; top: 179.5px; left: 106px; position: absolute;">Loading zoom</div></div>
                </a>
            </div>
            <br>
         <div style="padding:0px 85px;" class="clearfix">
            <ul class="clearfix" style="text-align:center;" id="thumblist">     
        <li style="margin-right:10px;"><a rel="{gallery: 'gal1', smallimage: './product/thumb642208-468-(1).JPG',largeimage: './product/642208-468-(1).JPG'}" href="javascript:void(0);" class="zoomThumbActive">
        <img width="50" border="0" src="product/thumb642208-468-(1).JPG"></a></li>
               	<li><a rel="{gallery: 'gal1', smallimage: './product/thumb202208-468-(2).JPG',largeimage: './product/202208-468-(2).JPG'}" href="javascript:void(0);">
        <img width="50" border="0" src="product/thumb202208-468-(2).JPG"></a></li>
                </ul>
        </div>
        </div>
        </td><td><h2>Gaun Wedding 208-468</h2><br><br>Gaun Wedding Ekor
<div>Kombinasi brokat, kristal dan mote serta d<span style="line-height: 1.5em;">itambah dengan engkol disekeliling gaun&nbsp;</span></div>
<div><span style="line-height: 1.5em;">Membuat gaun ini indah</span></div>
<div><span style="line-height: 1.5em;">Warna BW, Ukuran M dengan belakang tali tali</span></div>
<div><span style="line-height: 1.5em;">Harga Rp 4.850.000.-</span></div>
<div><span style="line-height: 1.5em;">Store RRKSD</span></div>
<div><span style="line-height: 1.5em;"><br></span></div><br><br>		<table><tbody><tr><td>
            <div class="fb-share-button fb_iframe_widget" data-type="button" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=&amp;container_width=34&amp;href=http%3A%2F%2Fwww.suanggown.com%2F%3Fmenu%3Dproduct_detail%26id%3D208-468&amp;locale=en_US&amp;sdk=joey&amp;type=button"><span style="vertical-align: bottom; width: 57px; height: 20px;"><iframe width="1000px" height="1000px" frameborder="0" name="f1790f39ae48b6a" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:share_button Facebook Social Plugin" style="border: medium none; visibility: visible; width: 57px; height: 20px;" src="http://www.facebook.com/plugins/share_button.php?app_id=&amp;channel=http%3A%2F%2Fstatic.ak.facebook.com%2Fconnect%2Fxd_arbiter%2Fjb3BUxkAISL.js%3Fversion%3D41%23cb%3Df2306bfe94729fa%26domain%3Dwww.suanggown.com%26origin%3Dhttp%253A%252F%252Fwww.suanggown.com%252Ff553d73e93926a%26relation%3Dparent.parent&amp;container_width=34&amp;href=http%3A%2F%2Fwww.suanggown.com%2F%3Fmenu%3Dproduct_detail%26id%3D208-468&amp;locale=en_US&amp;sdk=joey&amp;type=button" class=""></iframe></span></div>
			<script type="text/javascript" src="http://static.ak.fbcdn.net/connect.php/js/FB.Share"></script> </td><td>
            <iframe frameborder="0" id="twitter-widget-0" scrolling="no" allowtransparency="true" class="twitter-share-button twitter-share-button-rendered twitter-tweet-button" style="position: static; visibility: visible; width: 58px; height: 20px;" title="Twitter Tweet Button" src="http://platform.twitter.com/widgets/tweet_button.a428ab2e859e8008e0df5404770eb017.en.html#_=1445495305552&amp;count=none&amp;dnt=false&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Fwww.suanggown.com%2F%3Fmenu%3Dproduct_detail%26id%3D208-468&amp;size=m&amp;text=Suang%20Gown&amp;type=share&amp;url=http%3A%2F%2Fwww.suanggown.com%2F%3Fmenu%3Dproduct_detail%26id%3D208-468"></iframe>
			<script src="//platform.twitter.com/widgets.js" type="text/javascript"></script></td></tr></tbody></table>
		</td></tr></tbody></table></td></tr></tbody></table></div>
    
    <div id="footer_container">
    <table width="960" cellspacing="0" cellpadding="0" border="0"><tbody><tr valign="top">
    
    <td width="320" align="left">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
         <b>Need Assistance?</b>
<br><br><span style="color: #ff6600;"><b>
Contact our customer service</b></span><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr>
<td>
<p>Phone &nbsp; &nbsp;&nbsp;<br><b><span style="color: #ff6600;"><br>
      </span></b></p>
<p><b><span style="color: #ff6600;">WhatsApp</span></b><br><span style="line-height: 1.5em;">Email&nbsp;</span></p>
<p><b style="line-height: 1.5em; color: #ff6600;">Pin BB</b></p>
</td>
<td>: 08127172387&nbsp;<br>&nbsp; 021 22510107<br>&nbsp; 081273339878<br>: 08127849402<br>: suanggown@gmail.com<br><br>: <b>7A6D93E7</b><br></td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>        </div>
    </div>
    </td>
    <td width="320" align="center">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
        <b>Get Updates</b>
<br><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr valign="top">
<td><a href="http://www.facebook.com/#!/pages/Suang-Gown/180922218646165"><img width="31" height="29" src="/inliners/fb.png" style="border: 0pt none;"></a><br></td>
<td><a href="http://www.facebook.com/#!/pages/Suang-Gown/180922218646165"><b>Like Us</b></a><br>Join our fanpage on Facebook<br></td>
</tr>
<tr valign="top">
<td><a href="https://twitter.com/#!/suanggown"><img width="31" height="29" src="/inliners/twitter.png" style="border: 0pt none;"></a><br></td>
<td><a href="https://twitter.com/#!/suanggown"><b>Follow Us</b></a><br>Gets updates by following our twitter<br></td>
</tr>
</tbody>
</table>        </div>
    </div>    
    </td>
    
    <td width="320" align="right">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
        <b>Customer Service</b>
<br><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr>
<td width="130"><a href="/webadmin/ymsgr:sendim?suanggown777">
<img width="139" height="107" style="border: 0pt none;" src="http://opi.yahoo.com/online?u=suanggown777&amp;m=g&amp;t=14"></a> 
    </td>
<td><b>Rek BCA</b><br>0410342111<br>An. Ng Nyuk Sung<br><b>Rek Mandiri</b><br>160078494026<br>An. Ng Nyuk Sung</td>
</tr>
</tbody>
</table>        </div>
    </div>
    </td></tr>
    </tbody></table>
    </div>
	<div id="copyright">www.suanggown.com 2012. All Right Reserved. Powered By WitieStudio</div>

</div>
<!--[if IE]>
</div>
<![endif]-->



    
    </div><div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe frameborder="0" name="fb_xdm_frame_http" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_http" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" style="border: medium none;" src="http://static.ak.facebook.com/connect/xd_arbiter/jb3BUxkAISL.js?version=41#channel=f553d73e93926a&amp;origin=http%3A%2F%2Fwww.suanggown.com"></iframe><iframe frameborder="0" name="fb_xdm_frame_https" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" style="border: medium none;" src="https://s-static.ak.facebook.com/connect/xd_arbiter/jb3BUxkAISL.js?version=41#channel=f553d73e93926a&amp;origin=http%3A%2F%2Fwww.suanggown.com"></iframe></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div></div></body></html>