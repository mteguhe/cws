<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="col-md-4 about-left">
				
				<a href="single.html"><img src="<?php echo base_url(); ?>images/about.jpg" alt=""></a>
			</div>
			<div class="col-md-4z100 about-left">
				<h3>How to order</h3>
				<h4>
				Untuk berbelanja di toko online kami, pemesanan produk Central Wedding Shop
					dapat dilakukan dengan mudah, berikut petunjuk pembelian 
					secara online melalui website kami:</h4>
				<h4>scrambled it to make a type specimen</h4>
				<p>Since the 1500s, when an unknown printer a galley of type and scrambled specimen book.</p>
			    <h4>scrambled it to make a type specimen</h4>
			    <p> It has survivednot only five centuries, but also the leap into electronic typesetting.</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
</div>
		
