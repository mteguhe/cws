





<div id="footer">
<div id="inner-footer">
<div id="left-footer">
<div id="big-sub-content-title">Metode Pembayaran</div>
<div id="big-sub-content-center">
<div id="sub-rekening"><img src="<?php echo base_url(); ?>asset/images/bank-syariah.png" /><br />No. Rekening : <br /> 2857 027 105 <br />a/n Heri Kuswanto</div>
<div id="sub-rekening"><img src="<?php echo base_url(); ?>asset/images/bank-bri.png" /><br />No. Rekening : <br /> 6125-01-003271-53-9<br />a/n Heri Kuswanto</div>
<div id="sub-rekening"><img src="<?php echo base_url(); ?>asset/images/bank-bca.png" /><br />No. Rekening : <br /> 1800 658 299<br />a/n Heri Kuswanto</div>
<div id="sub-rekening"><img src="<?php echo base_url(); ?>asset/images/bank-mandiri.png" /><br />No. Rekening : <br /> 143-00-1170047-1<br />a/n Heri Kuswanto</div>
<div class="cleaner_h10"></div><div class="cleaner_h5"></div>
<p style="margin:0px auto; text-align:center; font-weight:bold;">Setelah melakukan pembayaran, silahkan konfirmasi pembayaran anda :</p>
<div class="cleaner_h10"></div>
<a href="<?php echo base_url(); ?>konfirmasi"><img src="<?php echo base_url(); ?>asset/images/bar-konfirmasi.png" style="float:left;" border="0" /></a><p style="float:left;">atau</p><img src="<?php echo base_url(); ?>asset/images/bar-konfirmasi-telpon.png" style="float:left;" />
</div>
<div id="big-sub-content-footer"></div>
</div>
<div id="right-footer">
<div id="big-sub-content-title">Bergabung Dengan Grup Kami Di Facebook</div>
<div id="big-sub-content-center">
<iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fharmonisgrosirsandal&amp;width=460&amp;colorscheme=light&amp;connections=8&amp;stream=false&amp;header=false&amp;height=180" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:460px; height:180px;" allowTransparency="true"></iframe>
</div>
<div id="big-sub-content-footer"></div>
</div>
<div class="cleaner_h10"></div>
<div id="menu-footer">Beranda | Tentang Kami | Cara Belanja | Konfirmasi Pembayaran | Hubungi Kami | Site Map Produk | Keranjang Belanja</div>
<div id="copy-footer">Copyright &copy; 2011 Grosir Sandal Online. All Rights Reserved.<br />
Anda berkunjung dengan IP Address 222.124.156.230</div>
</div>
</div>
</body>
</html>
