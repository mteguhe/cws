
    <div id="footer_container">
    <table width="960" cellspacing="0" cellpadding="0" border="0"><tbody><tr valign="top">
    
    <td width="320" align="left">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
         <b>Need Assistance?</b>
<br><br><span style="color: #ff6600;"><b>
Contact our customer service</b></span><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr>
<td>
<p>Phone &nbsp; &nbsp;&nbsp;<br><b><span style="color: #ff6600;"><br>
      </span></b></p>
<p><b><span style="color: #ff6600;">WhatsApp</span></b><br><span style="line-height: 1.5em;">Email&nbsp;</span></p>
<p><b style="line-height: 1.5em; color: #ff6600;">Pin BB</b></p>
</td>
<td>: 08127172387&nbsp;<br>&nbsp; 021 22510107<br>&nbsp; 081273339878<br>: 08127849402<br>: asdfghjkl@gmail.com<br><br>: <b>7A6D93E7</b><br></td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>        </div>
    </div>
    </td>
    <td width="320" align="center">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
        <b>Get Updates</b>
<br><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr valign="top">
<td><a href="http://www.facebook.com/#!/pages/Suang-Gown/180922218646165"><img width="31" height="29" src="<?php echo base_url();?>/images/fb.png" style="border: 0pt none;"></a><br></td>
<td><a href="http://www.facebook.com/#!/pages/Suang-Gown/180922218646165"><b>Like Us</b></a><br>Join our fanpage on Facebook<br></td>
</tr>
<tr valign="top">
<td><a href="https://twitter.com/#!/suanggown"><img width="31" height="29" src="<?php echo base_url(); ?>/images/twitter.png" style="border: 0pt none;"></a><br></td>
<td><a href="https://twitter.com/#!/suanggown"><b>Follow Us</b></a><br>Gets updates by following our twitter<br></td>
</tr>
</tbody>
</table>        </div>
    </div>    
    </td>
    
    <td width="320" align="right">
    <div class="footer_boxes_outer">
    	<div class="footer_boxes_inner">
        <b>Customer Service</b>
<br><br>
<table cellspacing="0" cellpadding="5" border="0" style="width: 280px;">
<tbody>
<tr>
<td width="130"><a href="/webadmin/ymsgr:sendim?suanggown777">
<img width="139" height="107" style="border: 0pt none;" src="http://opi.yahoo.com/online?u=suanggown777&amp;m=g&amp;t=14"></a> 
    </td>
<td><b>Rek BCA</b><br>0410342111<br>An. Ng Nyuk Sung<br><b>Rek Mandiri</b><br>160078494026<br>An. Ng Nyuk Sung</td>
</tr>
</tbody>
</table>        </div>
    </div>
    </td></tr>
    </tbody></table>
    </div>
	<div id="copyright">www.suanggown.com 2012. All Right Reserved. Powered By WitieStudio</div>

</div>
<!--[if IE]>
</div>
<![endif]-->



    
    </body></html>