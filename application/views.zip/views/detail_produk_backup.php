
<!--banner start here-->
<div class="">
</div>
<!--banner end here-->
<!--gallery start here-->
<div class="gallery">
	<div class="container">
		<div class="gallery-top">
			<h3>Welcome</h3>
			<p>Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances.</p>
		</div>
		<div class="gallery-bottom">
				<div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g1.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g1.jpg" alt="" width="360" height="260">
					</div>
				</div>
				<div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g2.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g2.jpg" alt="" width="360" height="260">
					</div>
				</div>
				<div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g3.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g3.jpg" alt="" width="360" height="260">
					</div>
				</div>
                <div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g4.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g4.jpg" alt="">
					</div>
				</div>
				<div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g5.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g5.jpg" alt="">
					</div>
				</div>
				<div class="col-md-4 gallery-grid">
					<div class="project-eff">
						<div id="nivo-lightbox-demo"> <p> <a href="<?php echo base_url(); ?>images/g6.jpg"data-lightbox-gallery="gallery1" id="nivo-lightbox-demo"> <span class="rollover1"> </span></a> </p></div>     
							<img class="img-responsive" src="<?php echo base_url(); ?>images/g6.jpg" alt="">
					</div>
				</div>
		   <div class="clearfix"> </div>
		</div>
	</div>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/magnific-popup.css">
			<script type="text/javascript" src="<?php echo base_url(); ?>js/nivo-lightbox.min.js"></script>
				<script type="text/javascript">
				$(document).ready(function(){
				    $('#nivo-lightbox-demo a').nivoLightbox({ effect: 'fade' });
				});
				</script>


<!--gallery end here-->