<?php
	include('header1.php');
?>
    
	<div class="hr_menubar"></div>
	<div id="menu_container"><div class="menu"><a href="<?php echo base_url();?>">Home</a></div>
	<div class="menu"><a href="<?php echo base_url();?>awal/about">Profil</a></div>
	<div class="menu"><a href="<?php echo base_url();?>awal/collection">Produks</a></div>
	<div class="menu"><a href="<?php echo base_url();?>awal/how_to_buy">Order</a></div>
	<div class="menu"><a href="<?php echo base_url();?>awal/testimonial">Testimonial</a></div>
	<div class="menu"><a href="<?php echo base_url();?>trend">Promo Ekstra</a></div>
	<div class="menu"><a href="<?php echo base_url();?>awal/faq">Contact Us</a></div>
	<div class="menu"><a href="<?php echo base_url();?>trend">Trend Mode</a></div>
	</div>
	
    <div id="content_container"><div id="content">
<table width="960" class="content_table"><tbody><tr valign="top"><td height="450" align="justify">
<h1>FAQ</h1><p></p><div>
<div style="font-weight: bold;"><b><span style="font-size: small;">Bagaimana Cara Memesan dan Berkomunikasi dengan Suang Gown</span></b></div>
<div>Memesan &amp; berkomunikasi dengan Suang Gown, bisa dengan contact langsung <b>Pin BB</b> 278B1D11, <b>YM</b> suanggown@yahoo.com atau dengan meninggalkan pesan ke <b>emai</b>l suanggown@gmail serta <b>facebook</b> &nbsp;suanggown.collection</div>
</div>
<b>
<div><b><br></b></div>
HOW CAN I PAY MY ORDER?</b><br>We accept the payment via BCA, Mandiri Account and Western Union. We cannot receive any payment through other account bank for the time being.&nbsp; If you buy in our shop in Town House Cordoba 59 PIK Jak-Ut, we accept <b>Credit Card Visa,</b> <b>Master</b>, <b>JCB and Prima Debit</b>.<br>
<div><br><b><span style="font-size: small;">Bagaimana cara saya melakukan pembayaran Gaun ?</span></b><br>Kami menerima pembayaran melalui BCA , rekening Mandiri serta Western Union. Kami tidak dapat menerima pembayaran melalui rekening bank lain untuk sementara waktu. Jika Anda membeli di show room kami di Town House Cordoba 59 PIK Jak Ut, kita menerima <b>Kartu Kredit Visa</b>,<b>&nbsp;Master</b>, <b>JCB</b> dan <b>Debit Prima</b></div>
<div><br><b>WHEN WILL MY ORDER BE SHIPPED?</b><br>Once you have transffered the money required, just click "CONFIRMATION" on the top of the page. Your product will be send the next day with JNE, after you have complete the payment confirmation. (Example: If you have complete the payment on Monday, we will send the product on Tuesday morning)<i>.</i><br><br><b><span style="font-size: small;">Kapan pesanan saya dikirim ?</span></b><br>Produk Anda akan dikirimkan pada hari berikutnya melalui JNE setelah Anda menyelesaikan konfirmasi pembayaran.Setelah Anda transfer uang yang dibutuhkan, cukup klik "KONFIRMASI" di bagian atas halaman. (Contoh: Jika Anda telah menyelesaikan pembayaran pada hari Senin, kami akan mengirimkan produk pada hari yang sama atau Selasa pagi).<br><br><b>HOW LONG WILL IT TAKE FOR MY PRODUCT TO BE ARRIVED?</b><br>We are using JNE or Fedex for the shipment delivery. Therefore you can choose what kind of service of&nbsp; that are available&nbsp; (Express or Regular Service). For the Express Service, it will take 1 day to be arrived at your home and for&nbsp; the Regular Service, it will take 3-4 days to be arrived at your home. <br><br><b><span style="font-size: small;">Berapa lama pesanan saya sampai ke tempat saya&nbsp;?</span></b><br>Untuk JNE Service Ekspres, akan memakan waktu 1 hari untuk tiba dirumah Anda dan untuk Kantor Reguler, akan memakan waktu 3-4 hari untuk tiba di rumah AndaKami menggunakan JNE atau Fedex untuk pengiriman pengiriman.Karena itu anda dapat memilih jenis layanan yang tersedia (Express atau Layanan Reguler).<br><br><b>WHAT IS YOUR RETURN POLICY?</b><br>Suang Gown Collection does not accept refund for change of mind or "wrong fit" as because we are providing the complete information about the product size. Therefore please carefuly read the information about the product.&nbsp; All sale items are strictly non refundable. <br><br><b><span style="font-size: small;">Kebijaksanaan Pengembalian Uang</span>.</b><br>Suang Gown Collection tidak menerima pengembalian dana untuk perubahan pikiran atau "tidak cocok ", karena kami menyediakan informasi lengkap tentang bahan dan ukuran produk. Oleh karena itu silahkan membaca informasi tentang produk dengan teliti. Semua item dijual secara ketat tidak ada pengembalian uang. Jika masih ada keraguan hubungin Customer Service kami.<br><br><b>CAN I ADD, REMOVE, CANCEL MY PRODUCTS AFTER MY ORDER IS PLACED?</b><br>Once your order has been submitted to us, we will then begin to process your order immediately. Please make sure that you are happy with your final choice before do the confirmation payment. We cannot cancel the Order, when goods already shipped to you address<br><br><b><span style="font-size: small;">Dapatkah Saya Membatalkan Order Saya Setelah Pesanan Dikirim ?</span></b><br>Setelah pesanan Anda telah diserahkan kepada kami, kami akan mulai memproses pesanan Anda segera. Pastikan bahwa Anda puas dengan pilihan akhir Anda sebelum melakukan konfirmasi pembayaran. Kami tidak dapat membatalkan Order, bila barang sudah dikirim ke alamat Anda.<br><br><b>I'M NOT SURE ABOUT MY SIZING?</b><br>In order to simplify the different sizing items, which can be very for each people- we have interpreted all sizing guides into the standardized S, M, L and XL.<br>Please be aware that the recommended sizes should be used as a guide only. We recommend you to be sure with what size of clothes that you use for everydaywear or you can contact us for assistance / help.<br><br></div>
<div style="text-align: justify;">
</div>
<div style="text-align: justify;">
</div>
<b><span style="font-size: small;">Saya Tidak Nyakin Dengan Ukuran Saya</span></b>
<div style="text-align: justify;">
</div>
<span style="font-size: small;">Untuk menyederhanakan item ukuran yang berbeda, yang bisa kami gunakan ukuran umun panduan sizing ke S standar, M, L dan XL.&nbsp;</span><br>Perlu diketahui bahwa ukuran yang direkomendasikan harus digunakan sebagai pedoman saja. Kami sarankan Anda untuk memastikan dengan apa ukuran pakaian yang Anda gunakan untuk sehari-hari atau Anda dapat menghubungi kami untuk bantuan / bantuan. Kami dengan senang hati membantu anda mengecilkan ataupun memperbesar ukuran gaun yang anda pilih.
<div><br>
<div></div>
<div><b><span style="font-size: small;">Dimana Lokasi show Room kami</span></b></div>
<div>Lokasi kami di Town House Cordoba 59 Pantai Indah kapuk Jakarta Utara tel 021 <b>26 390 308</b>, dekat dengan RS. PIK atau depan Water Boom Pantai Indah kapuk.</div>
<div></div>
<div></div>
<div><b>Price list</b></div>
<div>Untuk melihat Price List cara gaun yang dipilih dienter sekali lagi, akan keluar harganya. Kalau masih ada harga yang belum tercantum, harap hubungin kami atau di email.</div>
<div></div>
<div></div>
<div></div>
</div><p></p></td></tr></tbody></table>
</div></div>
    
<?php
	include('footer.php');
?>