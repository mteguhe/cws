<div class="about">
	<div class="container">
		<div class="about-main">
			<div class="col-md-4 about-left">
				<h3></h3>
				<a href="#"><img src="<?php echo base_url(); ?>images/about.jpg" alt=""></a>
			</div>
			<div class="col-md-4z100 about-left">
				<h3>About us</h3>
				<h4>Barang yang kami jual berkualitas</h4>
				<p>barang yang kami jual terbuat dari .... ... ... diganti nantinya of the printing and typesetting industry. Lorem Ipsum has been the industry.</p>
				<h4>Barang yang kami jual mewah</h4>
				<p>Since the 1500s, when an unknown printer a galley of type and scrambled specimen book.</p>
			    <h4>scrambled it to make a type specimen</h4>
			    <p> It has survivednot only five centuries, but also the leap into electronic typesetting.</p>
			</div>
		  <div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="histort">
	<div class="container">
		<div class="history-main">
			<h3>Our History</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione</p>
		    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto</p>
		</div>
	</div>
</div>
		
