<!--footer start here-->
<div class="footer">
	<div class="container">
		<div class="footer-main">
			  <div class="col-md-4 ftr-grd">
			  	 <h3>Contact Me </h3>
			  	 <p>Phone : 0818 7818 7068 </p>
			  	 <p>        0877 7514 5404 </p>
			  	 <p>        021  9472 4830 </p>
			  	 <br>
			  	 <p>WA / Line : 0818 7818 7068 </p>
			  	 <br>
			  	 <p>Email : centralweddingstore@gmail.com </p>
			  </div>
			  <div class="col-md-4 ftr-grd">
			  	 <h3>Follow Us</h3>
			  	 <ul>
			  	 	<li><a href="#"><span class="fa"> </span></a></li>
			  	 	<li><a href="#"><span class="tw"> </span></a></li>
			  	 	<li><a href="#"><span class="g"> </span></a></li>
			  	 	<li><a href="#"><span class="in"> </span></a></li>
			  	 </ul>
			  </div>
			  <div class="col-md-4 ftr-grd">
			  	 <h3>Join Our Newsletter</h3>
			  	 <p>Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus </p>
			  	 <label class="hvr-wobble-bottom"> <input type="submit" value="Send"></label>
			  </div>
			<div class="clearfix"> </div>
			<div class="copy-right">
			   <p>© 2015 Central Wedding Store. All rights reserved | Design Modified by  M Teguh E</p>
		   </div>
		</div>
	</div>
</div>
<!--//footer--> 
</body>
</html>