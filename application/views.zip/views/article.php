<?php
	include('header.php');
?>
    
	<div class="hr_menubar"></div>
	<div id="menu_container"><div class="menu"><a href="<?php echo base_url();?>">Home</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/about"> About Us</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/collection">Collections</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/testimonial">Testimonial</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/how_to_buy">How To Order</a></div>
<div class="menu_active"><a href="<?php echo base_url();?>index.php/awal/article">Article</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/faq">Faq</a></div>
<div class="menu"><a href="<?php echo base_url();?>index.php/awal/contact">Contact Us</a></div>
</div>
	
    <div id="content_container"><div id="content">
<table width="960" class="content_table"><tbody><tr valign="top"><td width="300" height="450">
	<div class="left_menu">
    <h1>Article</h1><br><br>
    <ul class="left_menu">
	<li><a href="?menu=article&amp;id=14">Grungy Oil-Slicked Black Glitter Eye</a></li><li><a href="?menu=article&amp;id=13">How to become a proffesional Makeup Artist</a></li><li><a href="?menu=article&amp;id=12">How to become a proffesional Makeup Artist</a></li><li><a href="?menu=article&amp;id=11">Tips Sempurnakan Calon Pengantin di Hari Bahagia</a></li><li><a href="?menu=article&amp;id=10">Tips Memilih Gaun Pengantin</a></li><li><a href="?menu=article&amp;id=6">Tips Merawat Wedding Dress</a></li>    </ul>
    </div>
</td><td>
<table width="700" border="0"><tbody><tr valign="top"><td><div class="list_img"><img width="150" border="0" src="pictures/"></div></td><td>
			  <h1><a href="?menu=article&amp;id=13">How to become a proffesional Makeup Artist</a></h1><div class="date">21 Mei 2012</div>Awal seniman cenderung memiliki masalah besar membobol bisnis. Hal ini terjadi karena minimnya pengetahuan tentang produk dan teknik. Cara terbaik untuk menjadi lebih baik dengan aspek-aspek ini adalah untuk berlatih melakukan riasan pada wajah sebagai sebanyak mungkin. Merias wajah pada teman dan keluarga Anda sampai Anda merasa apa yang dilakukan dan tidak bekerja pada bentuk wajah yang berbeda, warna kulit dan usia..<div class="read_more"><a href="?menu=article&amp;id=13"><img width="90" border="0" src="images/readmore.jpg"></a>
		</div></td></tr><tr><td colspan="2"><hr class="list_separator"></td></tr><tr valign="top"><td><div class="list_img"><img width="150" border="0" src="pictures/116makeup1.jpg"></div></td><td>
			  <h1><a href="?menu=article&amp;id=12">How to become a proffesional Makeup Artist</a></h1><div class="date">21 Mei 2012</div>Awal seniman cenderung memiliki masalah besar membobol bisnis. Hal ini terjadi karena minimnya pengetahuan tentang produk dan teknik. Cara terbaik untuk menjadi lebih baik dengan aspek-aspek ini adalah untuk berlatih melakukan riasan pada wajah sebagai sebanyak mungkin. Merias wajah pada teman dan keluarga Anda sampai Anda merasa apa yang dilakukan dan tidak bekerja pada bentuk wajah yang berbeda, warna kulit dan usia..<div class="read_more"><a href="?menu=article&amp;id=12"><img width="90" border="0" src="images/readmore.jpg"></a>
		</div></td></tr><tr><td colspan="2"><hr class="list_separator"></td></tr><tr valign="top"><td><div class="list_img"><img width="150" border="0" src="pictures/550images.jpg"></div></td><td>
			  <h1><a href="?menu=article&amp;id=11">Tips Sempurnakan Calon Pengantin di Hari Bahagia</a></h1><div class="date">18 Mei 2012</div>Menjaga penampilan itu penting apalagi bagi calon mempelai. Setiap calon
 pengantin pasti ingin terlihat sempurna dihari paling bersejarah dalam 
hidupnya. Segala perawatan dijalani demi tampil cantik dan memiliki 
kulit yang indah. Memang diperlukan usaha yang maksimal agar penampilan 
tidak mengewakan nantinya. Berikut beberapa hal yang penting dilakukan 
oleh calon pengantin wanita sebelum dan pada saat hari pernikahan.<div class="read_more"><a href="?menu=article&amp;id=11"><img width="90" border="0" src="images/readmore.jpg"></a>
		</div></td></tr><tr><td colspan="2"><hr class="list_separator"></td></tr><tr valign="top"><td><div class="list_img"><img width="150" border="0" src="pictures/372012-Fashion-Wedding-Dress-62910-.jpg"></div></td><td>
			  <h1><a href="?menu=article&amp;id=10">Tips Memilih Gaun Pengantin</a></h1><div class="date">07 Mei 2012</div><div style="text-align: justify;">Menjadi pengantin yang menakjubkan dan cantik adalah impian setiap pernikahan wanita. Menjadi pengantin yang sempurna membutuhkan banyak waktu dalam menemukan gaun pengantin yang tepat. Bagi perempuan plus ukuran, tugas ini adalah sedikit lebih sulit daripada untuk wanita yang memiliki tubuh langsing dan ramping dan dapat dengan mudah masuk dalam ukuran biasa. Tapi menjadi seorang wanita yang ukurannya sedikit lebih besar dari normal tidak selalu berarti bahwa menjadi pengantin yang cantik adalah mustahil. Beberapa wanita mungkin merasa ukuran plus sedikit berkecil hati pada awal pencarian mereka untuk gaun putih sempurna atau untuk gaun pengantin paling unik di butik dan toko departemen, sehingga menjadi siap secara emosional sangat penting untuk dapat menemukan gaun pengantin plus ukuran yang ideal . Berikut adalah tiga tips untuk membantu perempuan plus ukuran gaun pengantin menemukan yang terbaik untuk salah satu peristiwa yang paling diantisipasi dalam hidup mereka.<br><br></div><div class="read_more"><a href="?menu=article&amp;id=10"><img width="90" border="0" src="images/readmore.jpg"></a>
		</div></td></tr><tr><td colspan="2"><hr class="list_separator"></td></tr><tr valign="top"><td><div class="list_img"><img width="150" border="0" src="pictures/215261773_107653312662085_100002522513132_68206_8170353_n.jpg"></div></td><td>
			  <h1><a href="?menu=article&amp;id=6">Tips Merawat Wedding Dress</a></h1><div class="date">14 Maret 2011</div>Sebuah gaun pengantin (wedding dress) merupakan salah satu pembelian yang paling penting yang dapat membuat seorang wanita, dan sering salah satu biaya utama dari pernikahan. Setelah gaun pengantin telah dibeli, perawatan khusus harus diambil untuk menjaga pakaian dalam kondisi murni. Meskipun hal ini sangat penting untuk menjaga gaun pengantin dalam kondisi sempurna sebelum pernikahan, sebagian besar wanita akan setuju bahwa mereka ingin memastikan bahwa gaun pengantin mereka tetap dalam bentuk terbaik untuk tahun-tahun mendatang. Berikut tips-tips merawat gaun pengantin.<br><div class="read_more"><a href="?menu=article&amp;id=6"><img width="90" border="0" src="images/readmore.jpg"></a>
		</div></td></tr><tr><td colspan="2"><hr class="list_separator"></td></tr></tbody></table><br><br><div><div align="right" class="paging"> <span class="current">1</span> <a href="/?menu=article&amp;page=2"><b>2</b></a></div></div></td></tr></tbody></table>
</div></div>
    
<?php
	include('footer.php');
?>