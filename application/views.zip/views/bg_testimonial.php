<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- format penulisan '+nm+' salah...!\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' harus angka.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' harus angka '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' masih kosong...!\n'; }
  } if (errors) { alert('Oooopppzzz,,,,ada sedikit kesalahan pada :\n'+errors);
  document.MM_returnValue = (errors == ''); }
  else { document.MM_returnValue = (errors == ''); }
}
</script>


<div class="contact">
    <div class="container">
      <div class="contact-top">
        <h3>Testimonial</h3>
        <p> Terima kasih telah berbelanja....</p>
      </div>
      <div class="contact-form">
<form method="post" action="<?php echo base_url(); ?>index.php/testimonial/kirim_pesan">

  <input name="nama" type="text" class="input-teks" id="nama" size="50" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}"/>
  <input name="email" type="text" class="input-teks" id="email" size="50" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"/>
  <textarea name="pesan" cols="60" rows="6" class="input-teks" id="pesan" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message...';}"></textarea>
  <?php echo $gbr_captcha; ?> <input name="captcha" type="text" class="input-teks" id="captcha" size="20" value="Kode Capthca" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Kode Capthca';}"/>
<input type="submit" class="input-tombol" onclick="MM_validateForm('nama','','R','email','','RisEmail','captcha','','R','pesan','','R');return document.MM_returnValue" value="Kirim Testimonial" />


</form>
</div>
      
    </div>
  </div>
<!--isi testimonial end here-->
