<div id="content-center">
<div style="padding:5px; border:1px solid #ccc; margin-bottom:10px;"><a href="<?php echo base_url(); ?>">Beranda</a> > <a href="<?php echo base_url(); ?>hubungi_kami">Hubungi Kami</a> > Kirim Pesan</div>
<h1>Hubungi Kami - Harmonis Grosir Sandal Online</h1>
<?php echo $pesan; ?>
</div>
